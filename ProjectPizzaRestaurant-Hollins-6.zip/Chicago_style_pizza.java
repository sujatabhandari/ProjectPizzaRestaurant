
public class Chicago_style_pizza extends Pizza {

	@Override
	public Double basePrice() {
		return 10.99;
	}
	
public Double totalPrice(Chicago_style_pizza p) {
	return  p.basePrice()+p.toppingsPrice();
	}
	
	@Override
	public String toString()
	{
		Chicago_style_pizza p = new  Chicago_style_pizza();
		Double t =  this.totalPrice(p);
		
		return "Chicago style pizza has base price 11.99" ;
	}

	
}
