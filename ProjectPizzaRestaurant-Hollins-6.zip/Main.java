/*
The Main class should handle running the point of sale system for the pizza restaurant.

You should allow the user to input multiple orders each with multiple pizzas. Pizzas can be either traditional or deep dish, and have a variety of toppings. I suggest you have the user enter a string like "pm", where each letter stands for a topping, e.g. "pm" would be pepperoni and mushrooms.

Before you beginning, you add 4 toppings to your Restaurant's toppings ArrayList (using the Restaurant method addTopping). Remember Restaurant doesn't need to be instantiated, as there is only one, e.g. use Restaurant.addTopping("pepperoni", "1.29"). There are 4 toppings available. "pepperoni" and "extra cheese" are 1.29, "green peppers" and "mushrooms" are 0.99. 

I recommend creating multiple static methods in this Main class for specific purposes. One might handle reading in a single pizza. One might handle reading in an order of pizzas (and in that process calling the previous method). Break up the task like that.

After the user is done inputting all of their orders, the program should print out all of the orders (using the Restaurant's printOrders method) and the price of the priciest order (found using the Restaurant's priciestOrder method).

If you are working in a group (max size 3), add an extra feature of your choice for each person in the group beyond the first. An extra feature might be a new type of pizza or the ability to find the average price of a pizza.  
*/

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;

/*
The Main class should handle running the point of sale system for the pizza restaurant.

You should allow the user to input multiple orders each with multiple pizzas. Pizzas can be either traditional or deep dish, and have a variety of toppings. I suggest you have the user enter a string like "pm", where each letter stands for a topping, e.g. "pm" would be pepperoni and mushrooms.

Before you beginning, you add 4 toppings to your Restaurant's toppings ArrayList (using the Restaurant method addTopping). Remember Restaurant doesn't need to be instantiated, as there is only one, e.g. use Restaurant.addTopping("pepperoni", "1.29"). There are 4 toppings available. "pepperoni" and "extra cheese" are 1.29, "green peppers" and "mushrooms" are 0.99. 

I recommend creating multiple static methods in this Main class for specific purposes. One might handle reading in a single pizza. One might handle reading in an order of pizzas (and in that process calling the previous method). Break up the task like that.

After the user is done inputting all of their orders, the program should print out all of the orders (using the Restaurant's printOrders method) and the price of the priciest order (found using the Restaurant's priciestOrder method).

If you are working in a group (max size 3), add an extra feature of your choice for each person in the group beyond the first. An extra feature might be a new type of pizza or the ability to find the average price of a pizza.  
*/

class Main {

  public static void placeNewOrder() {
    Scanner sc1 = new Scanner(System.in);

    int n = sc1.nextInt();
    while (n > 0) {
      System.out.println(
          "Here are the toppings to choose from. Please choose pepperoni, extra cheese, green peppers, mushrooms, or bacon bits:");
      String top = sc1.nextLine();

      n--;
    }
  }

  public static void singlePizza(Order o) {
    Scanner sc1 = new Scanner(System.in);
    System.out.println("Which type of pizza do you want? Please choose 1 or 2 or 3");
    System.out.println("1. Deepdish pizza");
    System.out.println("2. Traditional pizza");
    System.out.println("3. Chicago style pizza");
    int choice1 = sc1.nextInt();
    if (choice1 == 1) {
      System.out.println(
          "Here are the toppings to choose from. Please choose pepperoni, extra cheese, green peppers, mushrooms, or bacon bits:");
      Scanner sc2 = new Scanner(System.in);
      String top = sc2.nextLine();
      DeepDishPizza dp = new DeepDishPizza();
      Topping t = Restaurant.getTopping(top);
      dp.addTopping(t);
      o.addPizza(dp);
      System.out.println(dp.toString());
      System.out.println(dp.showTotalPrice(dp));
    } 
    else if (choice1 == 2) {
      System.out.println(
          "Here are the toppings to choose from. Please choose pepperoni, extra cheese, green peppers, mushrooms, or bacon bits:");
      Scanner sc2 = new Scanner(System.in);
      String top = sc2.nextLine();
      TraditionalPizza trdp = new TraditionalPizza();
      Topping t = Restaurant.getTopping(top);
      trdp.addTopping(t);
      o.addPizza(trdp);
      System.out.println(trdp.toString());
      System.out.println(trdp.showTotalPrice(trdp));
    } else if (choice1 == 3) {
      System.out.println(
          "Here are the toppings to choose from. Please choose pepperoni, extra cheese, green peppers, mushrooms, or bacon bits:");
      Scanner sc2 = new Scanner(System.in);
      String top = sc2.nextLine();
      Chicago_style_pizza trdp = new Chicago_style_pizza();
      Topping t = Restaurant.getTopping(top);
      trdp.addTopping(t);
      o.addPizza(trdp);
      System.out.println(trdp.toString());
      System.out.println(trdp.showTotalPrice(trdp));
    }

  }

  public static void placeOrders() {
    System.out.println("How many order do you want to place?");
    Scanner sc = new Scanner(System.in);
    int n = sc.nextInt();
    while (n > 0) {
      System.out.println("How many pizzas do you want to order?");
      int p = sc.nextInt();
      if (p > 1) {
        Order o = new Order();
        for (int i = 0; i < p; i++) {
          singlePizza(o);
          System.out.println(o.toString());
        }
        Restaurant.addOrder(o);
        System.out.println("The average price of pizza for this order is: " + o.findAvgPizzaPrice());
      } else if (p == 1) {
        Order o = new Order();
        singlePizza(o);
        Restaurant.addOrder(o);
        System.out.println(o.toString());
        System.out.println("The average price of pizza for this order is: " + o.findAvgPizzaPrice());
      }
      n--;
    }

  }

  public static void main(String[] args) {
    Topping t1 = new Topping("pepperoni", 1.29);
    Restaurant.addTopping(t1);
    Topping t2 = new Topping("extra cheese", 1.29);
    Restaurant.addTopping(t2);
    Topping t3 = new Topping("green peppers", 0.99);
    Restaurant.addTopping(t3);
    Topping t4 = new Topping("mushrooms", 0.99);
    Restaurant.addTopping(t4);
    Topping t5 = new Topping("bacon bits", 1.99);
    Restaurant.addTopping(t5);

    placeOrders();
    System.out.println("The most expensive order is: " + Restaurant.priciestOrder());
  }
}