import java.util.Comparator;

public class SortOrders implements Comparator<Order>{

	@Override
	public int compare(Order o1, Order o2) {
		 if (o1.totalPriceOfOrder() == o2.totalPriceOfOrder()) {
	            return 0;
	        }
	        else if (o1.totalPriceOfOrder() < o2.totalPriceOfOrder()) {
	            return 1;
	        }
	        else {
	            return -1;
	        }
	}
}
