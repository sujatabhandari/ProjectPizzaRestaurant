
/*
The TraditionalPizza class should be a public class that is a subclass of Pizza. 

The class should implement the basePrice method as defined in the Pizza class. The base price of a TraditionalPizza is 8.99.

The class should have a public toString method that returns a String description of the Pizza.
*/
public class TraditionalPizza extends Pizza {

  @Override
  public Double basePrice() {
    return 8.99;
  }

  @Override
  public String toString() {
    TraditionalPizza p = new TraditionalPizza();
    Double t = p.totalPrice(p);

    return "TraditionalPizza has base price 8.99";
  }

  public Double totalPrice(TraditionalPizza p) {
    return p.basePrice() + p.toppingsPrice();
  }
}